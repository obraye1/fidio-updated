export default `FIDIO PRIVACY POLICY
Effective as of January 15, 2023 (Publication Date September 16, 2023)
Thank you for visiting Fidio.  Your privacy is important to us.  This privacy policy (‘Privacy Policy’)
describes how we, our affiliated and associated entities, as further detailed below (collectively ‘Fidio’,
‘we’, ‘us’ and ‘our’), collects, uses, discloses, transfers, stores, retains or otherwise processes your
personal data, and the choices you can make about the way your information is collected and used by
Fidio. Please review our Privacy Policy as it may change in the future and contact us at
privacy@fidio.ca or the correspondence address below if you have any questions or concerns or wish
to exercise your privacy rights.
It’s your right to:
Be informed about how we process your personal data.  We provide this information through our
Privacy Policy, our Services, and by answering your questions when you contact us.
Access your personal data.  You can ask whether we process your personal data, and if we do, you
can ask for a copy of your personal data and for information on certain other aspects of the
processing, including: the purposes of the processing; categories of the personal data processed;
recipients or categories of recipients of the data; source of the data where we have not received your
data directly from you; information about the existence of automated decision-making or profiling;
and information about other privacy rights you have in relation to your personal data.
Rectify inaccurate or incomplete personal data.  You may correct some categories of your personal
data yourself in your account settings or contact privacy@fidio.ca
Deletion (erasure) of your personal data.  You have the right to ask us to delete your personal data
under certain circumstances, including:
 Your personal data are no longer necessary in relation to the purposes for which we have
collected them;
 You withdraw your consent to processing of your personal data and there is no other legal
ground for the processing;
 You object to the processing and there are no overriding legitimate grounds for the processing
or when you object to the processing of your data for direct marketing purposes;
 Your personal data were unlawfully processed by us;
 The erasure is mandated under a law to which we are subject
 We have collected the personal data of a child.
Please know that you may also delete certain personal data by yourself in your Fidio account.  You
may also delete your folders, playlists, playlist descriptions, remove tracks from your playlists or
remove added artists and other content from your library.  Under some circumstances we are legally
not required to comply with a deletion request.  
In order to delete the personal data associated with your account, please contact privacy@fidio.ca or
visit Settings within the FIDIO app followed by Account. Click ‘Delete Account’.  Please note, you
must first cancel your existing subscription before being allowed to delete all of the personal
information associated with your account.  Please contact our support team at privacy@fidio.ca with
any questions or concerns about this process.
Restriction of processing of your personal data.  Under certain circumstances, you may request that
we stop processing some or all of your personal data temporarily.  You may request the restriction of
processing if:

 You have contested the accuracy of your personal data for the period of verification of the
accuracy of your personal data;
 When we unlawfully processed your personal data and instead of erasure of such data you
request restriction of their use;
 When we no longer need your personal data in relation to the purposes for which they were
collected but you require such data for the establishment, exercise or defense of legal claims;
 When you have objected to the processing, pending the verification on our end whether our
legitimate grounds override your interests.
Data Portability.  You have the right to receive a copy of your personal data in a machine-readable
(electronic) format and to have it sent to another service provider, if our legal basis for processing
your personal data is your consent or performance of contract.
Object.  You have the right to object to the processing of your personal data on certain grounds:
 When we process your personal data for our or third party’s legitimate interests.  When we
receive your request on this ground, we will no longer process your personal data for such
purposes, unless we demonstrate that we have compelling legitimate grounds to continue
processing your personal data for these purposes, which override your interests, rights and
freedoms or where we need to process such data for the establishment, exercise or defense of
legal claims.
 When we process your data for direct marketing purposes.  You can also object at any time
that we process your personal data for direct marketing purposes.  If you object, we will no
longer process your data for such purposes.  You may change your preferences and opt out
from receiving some or all of these types of direct marketing communications in your FIDIO
account settings, or you may contact us through the contact points provided in this Privacy
Policy (privacy@fidio.ca or our correspondence address below).  You may also unsubscribe
from our marketing emails by clicking on the unsubscribe link provided in such emails.
Not be subject to automated decision-making.  You have the right not to be subject to a decision based
solely on automated processing (i.e., decisions made by machines without human involvement),
including profiling, which would produce legal effects or similarly affect you significantly.  Our
processing of your data does not involve this type of automated decision-making.
Withdraw consent.  Where we rely on your consent to process your personal data for a particular
purpose, you may withdraw your consent at any time.  If you withdraw your consent, we will stop
processing your personal data for the specific purpose or purposes requested.  This does not affect the
lawfulness of processing of your data before you have revoked the consent.
Register a complaint.  If you reside in applicable jurisdictions, you are entitled, per local data
protection law, to contact your local authorities regarding any question, concern or complaint you
have relating to our processing of your personal data. 
Non-discrimination.  You have the right to not be discriminated against if you exercise any of your
privacy rights.  We will not discriminate against you or deny, charge different prices for, or provide a
different quality of our Services if you choose to exercise these rights, although some functionality
and features on the Services may change or no longer be available to you.
You can request to exercise any of your privacy rights with an email to privacy@fidio.ca with our
customer service support contact form, or by writing to the correspondence address below.  Please
note that when you make a request to exercise your rights, we may require that you provide
information and follow procedures so that we can verify your identity.  Where possible, we will
attempt to match the information that you provide in your request to information we already have to
verify your identity.  If we are able to verify your request, we will process it.  We will assess any

request to exercise these rights on a case-by-case basis.  We will respond to your request within the
periods required by applicable data protection law.  However, we may not always be able to comply
fully with your request, and we will notify you in that event.
For the purposes of this Privacy Policy, Fidio Technologies Inc. d/b/a ‘Fidio’ is the ‘controller’ of
your personal data. Fidio Technologies Inc. is registered as a Corporation in Canada, with
headquarters located at 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada. 
The correspondence address for FIDIO is 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada. As the
controller Fidio decides why and how your personal data are handled by FIDIO when you use our
services (‘Services’).  FIDIO is responsible for handling your data according to applicable data
protection rules.  Our policy is to process your personal data in accordance with applicable data
protection laws and regulations.  This Privacy Policy is separate from FIDIO’s Terms of Use
(‘Terms’), which govern your use and access to FIDIO Services.
This Privacy Policy applies when: you register a FIDIO account; you log in and use FIDIO’s content
and streaming services; you download and/or use FIDIO clients (e.g. FIDIO mobile applications,
desktop player, web player, or other technical interfaces provided by FIDIO; your personalization of
your user experience; you visit or interact with our websites and fan pages on social networks; our
websites, services, communications or documents refer to this Privacy Policy; you interact with us in
any other way, such as when you contact our customer support service, respond to our surveys,
participate in our competitions and giveaways, use our developer platform, and other
communications.  This Privacy Policy collectively refers to the above as processing of your data in the
context of provision of our Services. 
The Personal and Other Information We Collect
At FIDIO and FIDIO websites, you can order products, express an opinion, create playlists, and
subscribe to services such as online newsletters and paid streaming. The types of personally
identifiable information that may be collected at these pages include your: name, FIDIO account, user
and profile data (including privacy and marketing settings), address, location, e-mail address,
telephone number, fax number, contact preferences, credit card and other payment information,
Internet protocol address, date of birth, gender, Facebook, Twitter, Google or Apple user identifiers,
and details of how you use and interact with our websites and Services (e.g., your search queries,
login data, playlists, device information, network connection type, a record of customer service
emails, consumption data, listening behavior, surveys, sweepstakes and competitions entered, etc.). 
FIDIO may process information about you related to: identification data and contact data; account
data; subscription data; payment and billing data; usage data; login data; device data; network data,
marketing data; personal data processed in the context of customer support; personal data processed in
the context of surveys, interviews and user-testing; personal data processed in the context of
competitions and sweepstakes; personal data processed about you in the context of your interaction
with our fan pages on social media networks.
At certain parts of some of our Services and websites, only persons who provide us with the requested
personally identifiable information will be able to order products, programs, and services or otherwise
participate in the Service or and/website&#39;s activities and offerings.  We may draw inferences from any
of the information we gather via our websites and Services, including about your preferences.  We do
not deliberately collect sensitive personal data and would not use any such information except for the
purposes for which it is collected and as authorized by law.
We may also receive information about you from third parties that may have collected and transferred
your personal data to us in accordance with their own privacy policies and/or terms of use.  When we
receive such information from third parties, we may combine it with the other personal data that we

have collected about you as set out in this Privacy Policy and use such information either alone or in
combination with the other personal data we hold.
We also may collect certain non-personally identifiable information when you visit many of our web
pages such as the type of browser you are using (e.g., Safari, Internet Explorer), the type of operating
system you are using and information about your Internet service provider (e.g., Comcast, AT&amp;T) or
device (e.g., iPhone X, MacBook Pro) and other user-related general data (e.g., zip code, area code).
How We Use the Information We Collect
We may use the information you provide about yourself to fulfill your requests for our products,
programs, and services, to respond to your inquiries about our offerings, and to offer you other
products, programs or services that we believe may be of interest to you.  We sometimes use this
information to communicate with you, such as to notify you when a concert you have purchased is
available for download, to fulfill a request by you for an online newsletter, or to contact you about
your account with us.  If you enter into a giveaway, contest or other promotion, we may use the
information you provide to administer those programs.
The information we collect in connection with our website is used to provide an interactive
experience.  We use this information to facilitate participation in these online forums and
communities and, from time to time, to offer you new products, programs, or services.  As is the case
with most Internet services, we obtain some information automatically and store it in log files.  We
use this and other information to understand and analyze trends, to administer the site, to learn about
user behavior on the site, to improve our products and services, and to gather generalized
demographic information about our users.  We may use this information to market and advertise our
products and services.
When we process your personal data, we do so because we have specific and defined reasons as well
as a legal justification to do so.  We may process your personal data when:
 we have your consent.  When you have given us your free, informed, unambiguous consent to
process your personal data for a specific purpose.  You are free to withdraw your consent at
any time;
 it is necessary for the performance of a contract between you and FIDIO.  We rely on this
legal basis when you request our products and/or Services and we need to process your
personal data to deliver these Services according to our Terms.  We may also rely on this
legal basis to process your personal data where it is necessary to take certain procedural steps,
such as to authenticate your eligibility for our Services.;
 it is necessary for compliance with a legal obligation.  We may be subject to different legal or
regulatory obligations in jurisdictions where we operate, which require that we process certain
personal data for specific purposes;
 it is necessary for the legitimate interests of FIDIO or a third party.  We or a third party may
have legitimate interests to process your personal data for various purposes that benefit FIDIO
or third parties, such as other FIDIO users.  Prior to relying on this legal basis, we balance the
benefits of processing for FIDIO or third parties against your interests, rights and freedoms to
determine if we can rely on this legal basis.
We may collect, share, use or otherwise process personal data about you to provide our Services and
products to you; for payment and billing purposes; to personalize our websites, Services and product
offerings to you; to improve our websites, Services and products; for our analytics, forecasting and
reporting purposes; to diagnose, troubleshoot and fix technology and security problems and to test
whether our websites, Services and products perform as they should; to calculate royalty and other
payments to the content rights holders and other third parties; for marketing and advertising purposes;
to comply with legal obligations and to respond to appropriate legal requests; to enforce our Terms

and policies; to detect, investigate and take all steps necessary to address misuse, frauds or any
unlawful activity on our websites and Services; to establish and defend legal claims; to fulfill our
contractual obligations with third parties; for the purposes of competitions and sweepstakes; to
conduct surveys, interviews and user-testing sessions; to enable your participation in our FIDIO
subscription service and special offers; for customer support purposes; and to communicate with you
on social networks and to analyze the use of our fan pages.
You are not required to provide any personally identifiable information that we have requested, but if
you choose not to do so, in many cases we will not be able to provide you with our products or
services or respond to any questions you may have.
We sometimes use the non-personally identifiable information that we collect to improve the design
and content of our site and to enable us to personalize your Internet experience. We also may share
non-personally identifiable information publicly and with our partners and use this information in the
aggregate to analyze site usage, as well as to offer you products, programs, or services.
We share your data with third parties if you give us permission, if it is necessary for the performance
of the contract we have with you or if we have a legitimate interest for such sharing.  We may receive
and share information with our business partners, including third parties such as an artist, promoter,
venue, sponsor and/or strategic marketing and advertising partners.  Our business partners use the
information we give them as described in their privacy policies, which may include sending you
marketing communications. You should read those policies to learn how they treat your information. 
We may share information with our affiliates and group companies; our processors and service
providers; third-party applications, services and platforms (including audio devices, smart TVs, cars,
voice assistants, etc.); payment service providers; advertising and analytics service providers; auditors
and other third party accounting services; and any purchaser or successor to all or part of our business.
For example, if part of our business is sold we may give our customer list as part of that transaction.
We may disclose personally identifiable information in response to legal process (e.g. in response to a
court order or a subpoena), public authorities or to enforce applicable Terms, including investigation
of potential violations. We also may disclose such information to detect, prevent or otherwise address
fraud, intellectual property violations, security or technical issues, to protect our operations or users,
or to respond to a law enforcement agency&#39;s request. Additionally, in the event of a reorganization,
merger or sale we may transfer any and all information we collect to the relevant third party.
We may de-identify your data and combine and aggregate your de-identified information with other
information in a way that it no longer enables your identification and share that de-identified,
aggregated information with other third parties not mentioned above – for example, with artists or
content rights holders whose content we license. Such de-identified and aggregated statistics may
include demographic data, such as how many users constitute a particular age group, general locations
of where groups of users reside and similar data.
Agents and contractors of FIDIO who have access to personally identifiable information are required
to protect this information in a manner that is consistent with this Privacy Policy by, for example, not
using the information for any purpose other than to carry out the services they are performing for
FIDIO.
Although we take appropriate measures to safeguard against unauthorized disclosures of information,
we cannot assure you that personally identifiable information that we collect will never be disclosed
in a manner that is inconsistent with this Privacy Policy.
Finally, FIDIO websites will not use or transfer personally identifiable information provided to us in
ways unrelated to the ones described above without also providing you with an opportunity to opt out

of these unrelated uses. For example, if you don’t want to be on our mailing list, you can opt out by
updating your settings or contacting us at privacy@fidio.ca
Cookies
To enhance your experience with our website, many of our web pages use &quot;cookies.&quot; Cookies are text
files we place in your computer&#39;s browser to store your preferences. Cookies, by themselves, do not
tell us your e-mail address or other personally identifiable information unless you choose to provide
this information to us by, for example, registering at our site. However, once you choose to furnish the
site with personally identifiable information, this information may be linked to the data stored in the
cookie.
We use cookies to understand site usage and to improve the content and offerings on our site. For
example, we may use cookies to personalize your experience at Fidio.ca (e.g. to recognize you by
name when you return to our site), save your password in password-protected areas, and enable you to
use shopping carts on our website.
You may also set your browser to block all cookies, including cookies associates with our services, or
to indicate when a cookie is being set by us. However, many of our services may not function
properly if your cookies are disabled.
Social Media Networks
We use various usage and insight tools offered by the operators of social media networks, through
which we can view general, anonymized statistics about our fan pages, such as interactions and reach
of our posts and demographic information about our fan page visitors (e.g. age, gender, region).  We
can optimize the content we offer on our fan pages on that basis.  Whenever you interact with our fan
pages, operators of the social networks use cookies and similar technologies to track the usage
behavior of fan page visits. This information is collected regardless of whether you are a logged in
user of the particular social network or not.  On that basis, we receive various insights from the
operators of social networks. 
We do not have access to the personal data which the operators of social networks use to create such
insights. The selection and processing of your data for insights is performed exclusively by the
operators of social networks. However, in some cases, when using these usage analysis and insight
tools, we are jointly responsible (‘joint controllers’) with the operators of the social networks for
processing your data to the extent indicated below.
When you visit our profile or fan pages on Facebook and Instagram (each the ‘Social Media
Network’), the Social Media Network and FIDIO act as joint controllers with respect to the collection
of your data and the creation of insights. We have entered into joint controller terms with each Social
Media Network to govern the relationship between FIDIO and the Social Media Network with respect
to this processing. The Social Media Network is the primary controller for the collection of your data
that is used for the creation of insight reports.  The Social Media Network is therefore responsible for
enabling your privacy rights in line with the applicable privacy laws.  More information on how the
Social Media Network processes your personal data, including the legal basis the Social Media
Network relies on and the ways to exercise privacy rights against the Social Media Network, can be
found in each Social Media Network’s own Privacy Policy (Facebook, Instagram, etc.).
When you visit our Twitter or YouTube profiles, Twitter as the operator of Twitter or Google as the
operator of YouTube, as relevant, collects and processes your personal data to the extent described in
their privacy policies. Through statistics, we receive anonymized information from Twitter and
Google – for example about the number of our Twitter and YouTube profile visits, about how
successful our posts are or about what interests our followers pursue. Please refer to the Twitter and
YouTube privacy policies for further information on how they process your personal data.

Note that when you visit our fan pages, the operators of social media process your data also for their
own purposes, which are not covered in this Privacy Policy.  We have no influence over the data
processing operations of third parties.  In this regard, we refer you to the privacy policy of the
respective social network.
Links to Third Party Sites or Services
We may link to third party sites or services we don’t control.  If you click on one of those links, you
will be taken to websites we do not control.  This policy does not apply to the privacy practices of
those websites.  Read the privacy policy of these other websites carefully.  We are not responsible for
these third-party websites.  Our site may also serve third-party content that contains their own cookies
or tracking technologies.  We do not control the use of those technologies.
We do not track our customers across third-party websites; however, some third-party sites do keep
track of your browsing activities when they provide you content, which allows them to determine
what they present to you. If you are visiting such sites, your browser should allow you to set the Do
Not Track (DNT) signal so that third parties know you do not want to be tracked. Third parties that
have content embedded on FIDIO websites may set cookies on a user’s browser and/or collect
information about the fact that a web browser visited a specific FIDIO website from a certain IP
address. Third parties cannot obtain any other personally identifiable information from FIDIO’s
websites unless you provide it to them directly. Information collected by third parties is governed by
their privacy practices.
FIDIO offers interactive services which allow you to post content to share publicly or with friends. 
At any time you can contact privacy@fidio.ca to delete or remove content you have posted using the
deletion or removal options within our service.  Although we offer deletion capability for our services,
please be aware that the removal of content may not ensure complete or comprehensive removal of
that content or information posted through the services.
Information You Choose to Make Public
Certain information will be public on our websites and Services as part of your user experience
including your user name, and any public interactions you initiate on our websites or Services
including posting reviews, playlists, identifying favorite artists or performances, etc.  The extent of
your information visible to others on our websites and Services will depend on the information you
choose to share.  You can change or delete some of the information you provide.  If you use another
third party service or website to authenticate to our Services we will receive your first and last name
and profile information from these third parties and this information will be saved automatically in
your FIDIO account along with your user name and data.  You can also edit or delete this information.
You may be able to create public playlists on our Services.  Your public playlists will appear in your
user data, will be searchable on our Services and other FIDIO users can access and use them.  You
and other FIDIO users may be able to share user playlists and information via a shareable link or via
third-party social networks or messaging platforms.  You can change the privacy of your playlists at
any time.  If you change your public playlist to a private setting, it will no longer be searchable on our
Services or appear in any public user data.  Please be aware that if other FIDIO users access a
previously public playlist, subsequent changing of the playlist to a private setting will not
automatically remove the playlist for such other users.  If you shared your public or private playlist
through a shareable URL link or with other FIDIO users and they added such a playlist, at present you
can only remove the playlist from their collections by their deleting it. 
Children’s Personal Data
Our Services and their content are not directed at children under the age of 13. We do not knowingly
collect or solicit any personal data from children under the age of 13 or knowingly allow such persons

to register for our Services. If you are under the age of 13, please do not use our Services, do not
browse our websites and do not send us any of your personal data. If we learn that we have collected
personal data from a child under the age 13, we will promptly delete that information, in accordance
with applicable law. If you are a parent or guardian and believe that we may have collected personal
data from your child, please notify us immediately by sending an email to privacy@fidio.ca  If you
are 13 – 18 years of age, you may use our Services according to our Terms in appropriate
circumstances. We reserve the right to limit access to our Services for children aged 13 – 18 years, if
their use of our Services or processing of personal data would be illegal or would require a consent of
a parent or guardian, according to law applicable in their country of residence.  Do not play or
recommend any inappropriate content to individuals under 18 years old.
Data Retention, Deletion and Anonymization
Data Retention.  We will keep your personal data only for the period necessary to fulfil the purposes
for which we collect and process your personal data, as described in this Privacy Policy and in
accordance with applicable law. This means that the retention periods will vary according to the data
category and the purpose we have to process your personal data. The retention periods for data are
determined on a case-by-case basis that depends on the following factors:
 the nature of the personal data and why it is collected and processed. The length of time we
will keep your personal data will generally be determined by how long we need that
information to provide you with our Services and to provide customer support.  For example:
as set out in this Privacy Policy, we require account data to deliver our Services. We need to
keep it for the duration your FIDIO account exists so that we can maintain your account. 
Similarly, we will keep some of your usage data, such as your playlists or folders for the
lifetime of your account;
 for so long as we are required by law to do so.  We are subject to various legal obligations in
countries in which we operate, such as bookkeeping, accounting, tax or audit obligations,
which require that we keep certain data for specified periods. For example, we will keep your
information:
 to respond to a legal request or to comply with applicable law and where we have a legal
obligation to do so. For example, if we receive a valid legal request, such as a preservation
order or search warrant, related to your account, we preserve your information after you
delete your account;
 to deal with and resolve requests, disputes or complaints;
 for litigation or regulatory matters. For example, we preserve your information related to a
legal claim or complaint, such as where we are subject to a regulatory investigation or where
we need to defend ourselves in legal proceedings about a claim related to your information or
where we need to respond to a regulator in relation to a legal or regulatory complaint made by
you or someone else;
 for issues relating to the safety, security and integrity of our Services and to protect rights,
property and users. For example, we keep information where it is necessary to investigate
misuse of our Services, such as fraud.
Data Deletion and Anonymization.  Subject to applicable law, after the lapse of the retention
periods, we will delete or permanently anonymize your personal data so that it is no longer capable of
identifying you.  If you request that we delete your FIDIO user account, we will treat your FIDIO
account deletion request as a request for erasure (deletion) of your personal data and we will delete or
anonymize your personal data, so that it no longer identifies you, in accordance with applicable law.
Depending on the jurisdiction in which you reside, there may be circumstances in which we retain
your personal data for lawful reasons after receiving a deletion request, for example if:

 We have a legal obligation to keep some of your personal data;
 It is necessary for the establishment, exercise or defense of legal claims (e.g., when there is an
unresolved issue or claim relating to your FIDIO user account or your use of our Services);
 We have compelling legitimate grounds to retain some of your personal data that overrides
your interests in having your data deleted (e.g., for fraud prevention purposes, to enforce our
Terms, etc.)
 We cannot verify your identity or confirm that the personal data that we maintain relates to
you, or if we cannot verify that you have the authority to make a request on behalf of another
individual;
 There is another exception under the applicable legislation in the country or state of your
residence (e.g., exceptions applicable under the California Consumer Privacy Act)
In such cases, we will keep limited information about you in a protected form for the period necessary
to fulfil processing under the applicable exception.
Our Commitment to Security
We have put in place appropriate physical, electronic, and managerial procedures to safeguard and
help prevent unauthorized access, maintain data security, and correctly use the information we collect
online.
We use standard security measures in place to protect your information.  These measures will depend
on the type of information collected.  However, as the Internet is not guaranteed to be secure, we
cannot promise that your use of FIDIO sites and Internet-based services and applications will be
completely safe.  If you believe that an unauthorized account has been created with your name or
identity, contact us at the address below.
We recommend that you always use strong passwords, that you change them regularly and that you do
not use the same passwords for your FIDIO account as you already use to access other services or
devices.  We also recommend that you always access the Services and make payments from a secure
computer or device.  Any third-party services that you use to connect to your FIDIO account may also
affect your information.
ADDITIONAL DISCLOSURES FOR INDIVIDUALS RESIDING IN SELECT
JURISDICTIONS
CANADA
This section is relevant if you reside in Canada.  FIDIO complies with the Canadian Personal
Information Protection and Electronic Documents Act (‘PIPEDA’).  This Privacy Policy includes all
the necessary disclosures required by the PIPEDA.  If you are not satisfied with how we handled your
privacy request, please contact admin@fidio.ca and please note you have the right to make a written
submission indicating your concerns to the Privacy Commissioner in your jurisdiction or to the Office
of the Privacy Commissioner of Canada at the following address: Office of the Privacy Commissioner
of Canada, 30 Victoria Street Gatineau, Quebec K1A 1H3.  https://www.priv.gc.ca/en
THE EUROPEAN ECONOMIC AREA AND THE UNITED KINGDOM
This section is relevant if you reside in any of the European Economic Area countries (the ‘EEA’)
(i.e., Austria, Belgium, Bulgaria, Croatia, Republic of Cyprus, Czech Republic, Denmark, Estonia,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Lichtenstein, Lithuania,
Luxembourg, Malta, Netherlands, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain and
Sweden) or in the United Kingdom (the ‘UK’) and includes disclosures required by the General Data
Protection Regulation (Regulation (EU) 2016/679 and its UK equivalent, UK Data Protection Act
2018) (the ‘GDPR’). 

The GDPR gives you rights as described in this Privacy Policy, which you can exercise through the
contacts and methods provided in this Privacy Policy.
If you are not satisfied with how we handled your request to exercise any of your rights or you have
any other questions or concerns about your rights or this Privacy Policy, please contact
admin@fidio.ca send us a letter to our correspondence address as provided in this Privacy Policy. 
You also have the right to register a complaint with the relevant data protection authority.  You may
contact your local data protection authority about any questions or concerns you may have.  You can
find the overview of data protection authorities in different EEA countries at:
https://www.eeassoc.org/privacy-notice and the data protection authority for the UK is the
Information Commissioner’s Office, which you may contact at: https://ico.org.uk/global/contact-us/
As described above in this Privacy Policy, we share your data both internally and with our content
providers, affiliates and partners and processors and third-party vendors.  Some of these recipients are
located in countries outside the EEA and the UK, including in the United States and other countries,
whose laws may not provide an equivalent level of protection for your personal data as is the level of
protection guaranteed in the EEA and the UK.  These transfers are necessary and essential for us to
provide our Services to you.  Prior to your personal data being shared with third parties, we will take
contractual or other steps reasonably necessary to ensure that your personal data is treated securely by
such third parties.  To transfer your data, we rely on adequacy decisions issued by the European
Commission and the UK International Data Transfer Addendum.  For more information, including
how to obtain a copy of these documents please contact us through our contact points provided above
in this Privacy Policy.  You may also find the Standard Contractual Clauses approved by the
European Comission at: https://commission.europa.eu/law/law-topic/data-protection/international-
dimension-data-protection/standard-contractual-clauses-scc_en.
Amendments to this Privacy Policy
Our websites and Services are subject to constant improvements, and future changes may influence
what personal data we process and how we collect, use, share, store or otherwise process it.  We may
develop other Services in the future which are currently not mentioned in this Privacy Policy.  The
Privacy Policy will apply to them accordingly, unless stated otherwise upon the launch of the new
Services.
This Privacy Policy may be updated to reflect new changes in our Services, changes in legal
framework or improvements in how we handle personal data. When we make material changes to the
Privacy Policy, we will provide you with notice as appropriate under the circumstances, by sending
you an email or notification within a FIDIO client.  Unless stated otherwise, our most recent Privacy
Policy applies to all information that we process about you.
How to Contact Us
If you have any questions or concerns about the FIDIO Privacy Policy for this site our Services or its
implementation you may contact our Data Protection Office at privacy@fidio.ca or at the address
below:
Fidio Technologies Inc. 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada. 
Attn: Privacy
©FIDIO`;
